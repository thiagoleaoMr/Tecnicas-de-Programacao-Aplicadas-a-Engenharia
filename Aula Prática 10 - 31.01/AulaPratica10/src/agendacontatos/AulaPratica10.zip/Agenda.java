package agendacontatos;
import java.util.ArrayList;

public class Agenda {
    
    private ArrayList<Pessoa> listaContatos;
    
    public Agenda(){
        listaContatos = new ArrayList <>();
    }
    
    public Pessoa buscarPessoa (String s){
        for (Pessoa p: listaContatos){
            if(p instanceof PessoaFisica){
                PessoaFisica pFisica = (PessoaFisica)p;
                if(pFisica.getCpf().equals(s))
                    return pFisica;
            }else if(p instanceof PessoaJuridica){
                PessoaJuridica pJuridica = (PessoaJuridica)p;
                if(pJuridica.getCnpj().equals(s))
                    return pJuridica;
            }
        }
        return null;
    }
    
    public void adicionarContato(Pessoa p){
        listaContatos.add(p);        
    }
    
    public void removerContato(String s){
        if(buscarPessoa(s) != null)
            listaContatos.remove(s);
        else
            System.out.println("Erro! Contato inexistente.");
    }
    
    public void listarContatos() {
        for (Pessoa p: listaContatos) 
            System.out.println(p);
    }
}